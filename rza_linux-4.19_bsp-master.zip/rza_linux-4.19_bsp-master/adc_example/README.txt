This is an example of reading an ADC from application space by directly
accessing the ADC registers without a kernel driver.

It reads AD7, which on the RZ/A1H RSK board is connected to potentiometer
labeled "RV1" next to the push buttons.
